#include <iostream>
using namespace std;

int main() {
    // declare variables as always and it is important 
    int age, creditHours, feePerCreditHour;

    //  now input from the user
    cout << "Enter your age: ";
    cin >> age;

    cout << "Enter credit hours: ";
    cin >> creditHours;

    cout << "Enter fee per credit hour: ";
    cin >> feePerCreditHour;

    //  fees i will calculate here 
    int totalFee = creditHours * feePerCreditHour;
    int discountedFee = totalFee - 2000;

    // running calculation for birth year and year 25
    int birthYear = 2026 - age;
    int yearTurning25 = birthYear + 25;

    // ddisplay results
    cout << "\nTotal fee: Rs. " << totalFee << endl;
    cout << "Fee after Rs. 2000 discount: Rs. " << discountedFee << endl;
    cout << "Year of birth: " << birthYear << endl;
    cout << "Year you will turn 25: " << yearTurning25 << endl;

    return 0;
}

// experiment time hehe 

// Experiment 1:
// I entered all three values on one line separated by spaces 19 15 8000
// The program correctly stored the values 


// output was this 
/* Total fee: Rs. 120000
Fee after Rs. 2000 discount: Rs. 118000
Year of birth: 2007
Year you will turn 25: 2032*/

// then i entered the values on separate lines and separated by tabs
// the results were the same because cin ignores whitespace when reading integers

// Experiment 2:
// i entered 19.8 as the age
// The integer variable age stored 19, and .8 remained in the input stream.
// The next integer input failed because .8 is not a valid integer input it will be considered in float or double data type but not in int data type
// This happens because int stores whole numbers, not decimal values.