#include <iostream>
using namespace std;

int main() {
    cout << "Expression 1: " << 10 + 5 * 2 << endl;       // Output 20
    cout << "Expression 2: " << (10 + 5) * 2 << endl;     // output 30
    cout << "Expression 3: " << 20 - 5 - 3 << endl;       // Output 12
    cout << "Expression 4: " << 100 / 7 << endl;           // Output 14
    cout << "Expression 5: " << 100 % 7 << endl;           // Output 2
    cout << "Expression 6: " << 2 * 3 + 8 / 4 - 1 << endl; // output 7


    /*exp 3 is evaluated from left to right

    // adding brackets to make expression 6 equal 8 = 
    // 2 * 3 + 8 / 4 - 1
    // valid solution is not possible by adding brackets oonly here
    // while keeping all the original numbers and operators */


    return 0;
}