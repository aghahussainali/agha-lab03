#include <iostream>
using namespace std;

int main()
{

    // in first part there were 4 total syntax error and 1 logical 
    //  Corrected program

    cout << "Orientation Day" << endl;
    // semicolon was missing 
    cout << "Total students: " << 450 << endl;
    cout << "Seats left: " << 500 - 450 << endl;
    // << was missing dude after 450
    cout << "Have a nice day" << endl;
    // double quotes was missing afer day 

    // now second prt Semantic error

    // Original line prints because division happens before addition
    cout << "Average: " << 60 + 70 + 80 / 3 << endl;

    // Corrected line: brackets calculate first
    cout << "Average: " << (60 + 70 + 80) / 3 << endl;

    return 0;
}

/*
Syntax error: A mistake in the grammar
that prevents the program to run

Semantic error: A mistake in the logic of a program
that can produce an incorrect answer even when it compiles

The compiler catches syntax errors but it usually
does not catch logical semantic errors.
*/