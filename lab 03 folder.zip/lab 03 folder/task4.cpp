#include <iostream>
using namespace std;

int main() {
    int rollNo = 1045;
    int semester = 1;
    char section = 'B';
    float cgpa = 3.5;
    int totalFee = 45000;
    int feePaid = 20000;

    // im going to addd student information is here 

    cout << "Roll No: " << rollNo << endl;
    cout << "Semester: " << semester << endl;
    cout << "Section: " << section << endl;
    cout << "CGPA: " << cgpa << endl;
    cout << "Total Fee: " << totalFee << endl;
    cout << "Fee Paid: " << feePaid << endl;

    // now let's move to the next semester

    semester = semester + 1;

    // adding  the second installment

    feePaid = feePaid + 5000;

    // calculate remaining fee and percentage paid formula type here

    int remainingFee = totalFee - feePaid;
    int percentagePaid = feePaid * 100 / totalFee;

    cout << "Semesster: " << semester << endl;
    cout << "Fee Paid: " << feePaid << endl;
    cout << "Remaining Fee: " << remainingFee << endl;
    cout << "Percentage Paid: " << percentagePaid << endl;

    /* Identifier validity check here 
    2ndYear Invalid starts with a digit
    student_name: Valid
    total-marks: Invalid_fee: Valid
    Roll No: Invalid contains a space marks2: Valid

     Observation:
    An uninitialized local int may contain an unpredictable value that is why 
     it is unsafe to rely on it */

    return 0;
}