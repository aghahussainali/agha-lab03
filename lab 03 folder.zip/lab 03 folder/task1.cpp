// Agha Hussain Ali 
// Rol No 0123

#include<iostream>
using namespace std;
int main() {


    cout << "Hello World!" << endl;

    // Print university information using one cout statement
    cout << "University of Central Punjab\nFaculty of Information Technology\nOrientation Day 2026\n";

    // Print Welcome using endl
    cout << "Welcome!" << endl;

    // Print numbers and expressions
    cout << 2026 << endl;
    cout << 45 << endl;
    cout << 45 * 3 << endl;
    cout << 1000 + 500 - 250 << endl;

    // Print total fee using one cout statement
    cout << "Total fee: " << 45000 + 9000 << endl;

    return 0;



}