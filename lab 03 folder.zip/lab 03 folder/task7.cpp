
#include <iostream>
using namespace std;

int main() {
    int celsius, fahrenheit;

    cout << "Enter temperature in Celsius: ";
    cin >> celsius;

    fahrenheit = celsius * 9 / 5 + 32;

    cout << "Temperature in Fahrenheit: "
        << fahrenheit << endl;

    // int division removes the decimal part here so don't panic here
    return 0;
}
